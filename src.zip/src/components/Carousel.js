import React, { useState, useEffect } from 'react'
import { View,FlatList, Animated } from 'react-native'
import CarouselItem from './CarouselItem'

const Carousel = ({ data }) => {
    const scrollX = new Animated.Value(0)
    const [dataList, setDataList] = useState(data)

    useEffect(()=> {
        setDataList(data)
      
    })
    if (data && data.length) {
        return (
            <View>
                <FlatList data={dataList}
                    keyExtractor={(item, index) => 'key' + index}
                    horizontal
                    pagingEnabled
                    scrollEnabled
                    snapToAlignment="center"
                    scrollEventThrottle={16}
                    decelerationRate={"fast"}
                    showsHorizontalScrollIndicator={false}
                    renderItem={({ item }) => {
                        return <CarouselItem item={item} />
                    }}
                    onScroll={Animated.event(
                        [{ nativeEvent: { contentOffset: { x: scrollX } } }]
                    )}
                />
            </View>
        )
    }
    return null
}

export default Carousel


