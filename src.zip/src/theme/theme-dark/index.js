import App from './App';
import Module from './Module';
export default {
    App,
    Module,
};