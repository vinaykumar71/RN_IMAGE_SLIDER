/**
 * Home Screen functional component with Hooks
 * Display music list in gridview with thumbnail
 * @format
 * @flow
 */
import React, { useEffect } from 'react';
import { Text, View, NativeModules, Platform } from 'react-native'
import { useSelector, useDispatch } from 'react-redux';
import { Loading } from '_components/Loading';
import { fetchImages } from '../redux/ActionCreators';
import { styles } from './style';
import Carousel from '../../components/Carousel'

const { RNConnectionStatus } = NativeModules;

const HomeScreen = () => {
    const images = useSelector(state => state.images)
    const dispatch = useDispatch();

    useEffect(() => {
        if (Platform.OS === 'android') {
            NativeModules.CheckInternet.getInternetStatus(err => {
                alert(err);
            }, msg => {
                dispatch(fetchImages());
            },
            );
        } else {
            const hasInternetConnection = RNConnectionStatus.hasInternetConnection;
            if (hasInternetConnection) {
                dispatch(fetchImages());
            } else {
                console.log('No Internet Connection');
            }
        }
    }, [])

    if (images.isLoading) {
        return (
            <Loading />
        );
    }
    else if (images.errMess) {
        return (
            <View style={styles.container}>
                <Text>{`Network Error: ${images.errMess}`}</Text>
            </View>
        );
    }
    else {
        return (
            <View style={styles.container}>
                <Carousel data={images.image} />
            </View>
        );
    }

}

export default HomeScreen;
