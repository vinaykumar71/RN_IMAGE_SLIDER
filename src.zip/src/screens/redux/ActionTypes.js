
/*
* Action Types
* File contains all action types.
*
*/
//Get Image
export const FETCH_IMAGE_SUCCESS = 'FETCH_IMAGE_SUCCESS';
export const FETCH_IMAGE_ERROR = 'FETCH_IMAGE_ERROR';
export const FETCH_IMAGE_LOADING = 'FETCH_IMAGE_LOADING';


