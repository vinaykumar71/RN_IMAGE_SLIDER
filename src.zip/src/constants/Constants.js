export const BASE_URL = 'https://picsum.photos/';
export const APP_NAME = "APP_NAME";
//APP test base url
