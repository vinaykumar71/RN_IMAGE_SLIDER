/*
* Config File
* File contain white label cofiguration
*
*/
import React from 'react';
import { Text, View } from 'react-native';

const style = require('../theme')('Module')

const index = () => {
    return (
        <View>
            <Text>
                Module <Text style={styles.accent}>Bar</Text>
            </Text>
        </View>
    )
}

export default {
    name: 'Bar',
    component: 'BarComponent'
};
