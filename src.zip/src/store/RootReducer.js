import { combineReducers } from 'redux';
import { images } from '_screens/redux/Reducer';

const RootReducer = combineReducers({
    images
});

export default RootReducer;
